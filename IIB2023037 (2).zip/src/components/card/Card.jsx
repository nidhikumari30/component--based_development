import React from 'react';

const Card = () => {
    return (
        <>
            <div>
                <h1>card</h1>
            </div>
        </>
    );
}

export default Card;
